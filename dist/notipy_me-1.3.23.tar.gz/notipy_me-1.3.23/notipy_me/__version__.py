"""Current version of the NotipyMe package."""
__version__ = "1.3.23"
