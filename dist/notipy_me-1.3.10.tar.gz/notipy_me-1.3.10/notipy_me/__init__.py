from .notipy_me import Notipy

__all__ = [
    "Notipy"
] 