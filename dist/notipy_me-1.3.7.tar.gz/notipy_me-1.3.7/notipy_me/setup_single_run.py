from notipy_me import Notipy

def setup_single_run():
    Notipy()._setup(setup_single_run=True)